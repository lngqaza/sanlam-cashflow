import { useState, useEffect, useRef, useMemo } from "react";
import {
  AreaChart, Area, LineChart, Line, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  RadialBarChart, RadialBar, Cell, ReferenceLine, ComposedChart
} from "recharts";

// ─── ROLE THEMES ──────────────────────────────────────────────────────────────
const ROLES = {
  ADVISER: {
    id: "ADVISER", label: "Financial Adviser", icon: "◈",
    tagline: "Client Planning Suite",
    display: "'Playfair Display', Georgia, serif",
    body: "'Barlow', 'Trebuchet MS', sans-serif",
    mono: "'Courier New', monospace",
    bg: "#03142B", surface: "#071E3D", card: "#0A2647",
    border: "#1A3A5C", accent: "#C9922A", accent2: "#E8B84B",
    text: "#E8E0D0", muted: "#6B8CAE", dim: "#2A4A6A",
    positive: "#4CAF7D", negative: "#E05C5C", warning: "#E8B84B",
    glow: "rgba(201,146,42,0.15)", headerBg: "linear-gradient(135deg,#071E3D,#03142B)",
    tabs: ["Dashboard","Portfolio","Monte Carlo","Goals","Tax & Estate","Scenarios","AI Agent","Outputs"],
  },
  CLIENT: {
    id: "CLIENT", label: "Client Self-Service", icon: "◉",
    tagline: "My Financial Plan",
    display: "'Lora', Georgia, serif",
    body: "'Nunito', 'Segoe UI', sans-serif",
    mono: "'Courier New', monospace",
    bg: "#FBF7F1", surface: "#FFFFFF", card: "#FFFFFF",
    border: "#E8DDD0", accent: "#C86B3A", accent2: "#E8974E",
    text: "#2C1810", muted: "#9A7B6A", dim: "#E8DDD0",
    positive: "#2E7D52", negative: "#C0392B", warning: "#D68910",
    glow: "rgba(200,107,58,0.12)", headerBg: "linear-gradient(135deg,#FBF7F1,#F5EDE2)",
    tabs: ["My Plan","My Goals","My Products","Ask ARIA","Share"],
  },
  ACTUARY: {
    id: "ACTUARY", label: "Actuarial Analyst", icon: "⬡",
    tagline: "Computation Engine",
    display: "'Courier New', 'Lucida Console', monospace",
    body: "'Courier New', monospace",
    mono: "'Courier New', monospace",
    bg: "#080810", surface: "#0C0C18", card: "#10101E",
    border: "#1A1A2E", accent: "#00FF88", accent2: "#00CC66",
    text: "#B0FFD0", muted: "#406050", dim: "#1A2A20",
    positive: "#00FF88", negative: "#FF4466", warning: "#FFAA00",
    glow: "rgba(0,255,136,0.12)", headerBg: "linear-gradient(135deg,#0C0C18,#080810)",
    tabs: ["Engine","Simulation","Distribution","Raw Output","Export"],
  },
  COMPLIANCE: {
    id: "COMPLIANCE", label: "Compliance Officer", icon: "⬛",
    tagline: "FAIS Audit & Review",
    display: "'Georgia', serif",
    body: "'Helvetica Neue', Helvetica, sans-serif",
    mono: "'Courier New', monospace",
    bg: "#F8F9FA", surface: "#FFFFFF", card: "#FFFFFF",
    border: "#DEE2E6", accent: "#C0392B", accent2: "#E74C3C",
    text: "#212529", muted: "#6C757D", dim: "#F0F0F0",
    positive: "#155724", negative: "#721C24", warning: "#856404",
    glow: "rgba(192,57,43,0.08)", headerBg: "linear-gradient(135deg,#FFFFFF,#F8F9FA)",
    tabs: ["Plan Review","Audit Log","FAIS Flags","ROA Status","Reports"],
  },
  EXECUTIVE: {
    id: "EXECUTIVE", label: "Executive Dashboard", icon: "◆",
    tagline: "Command Centre",
    display: "'Impact', 'Arial Black', sans-serif",
    body: "'DM Sans', 'Segoe UI', sans-serif",
    mono: "'Courier New', monospace",
    bg: "#050A14", surface: "#0A1628", card: "#0F1F35",
    border: "#1A3050", accent: "#3B9EFF", accent2: "#60BAFF",
    text: "#E8F4FF", muted: "#5A80AA", dim: "#1A3050",
    positive: "#22C55E", negative: "#EF4444", warning: "#F59E0B",
    glow: "rgba(59,158,255,0.15)", headerBg: "linear-gradient(135deg,#0A1628,#050A14)",
    tabs: ["Overview","Adviser Activity","Portfolio Mix","Risk Alerts","Intelligence"],
  }
};

const ROLE_ORDER = ["ADVISER","CLIENT","ACTUARY","COMPLIANCE","EXECUTIVE"];

// ─── MOCK DATA ────────────────────────────────────────────────────────────────
const genNetWorth = () => Array.from({length:25},(_,i)=>({
  year:i+1,
  assets:Math.round(1_200_000*Math.pow(1.097,i)+i*48000),
  liabilities:Math.max(0,Math.round(980_000*Math.pow(0.88,i))),
  netWorth:Math.round(1_200_000*Math.pow(1.097,i)+i*48000-Math.max(0,980_000*Math.pow(0.88,i))),
  p10:Math.round(800_000*Math.pow(1.06,i)), p25:Math.round(1_000_000*Math.pow(1.08,i)),
  p50:Math.round(1_200_000*Math.pow(1.097,i)), p75:Math.round(1_500_000*Math.pow(1.12,i)),
  p90:Math.round(1_900_000*Math.pow(1.135,i)),
}));
const NW_DATA = genNetWorth();

const MC_DATA = NW_DATA.map(d=>({...d,
  successRate: Math.min(98, 62 + d.year*1.4),
  ruinProb: Math.max(2, 38 - d.year*1.4)
}));

const CASH_FLOW = Array.from({length:20},(_,i)=>({
  year:i+1,
  inflow:i<15?0:Math.round(280000+i*12000),
  outflow:Math.round(148000+i*3200),
  net:i<15?-Math.round(148000+i*3200):Math.round(280000+i*12000-148000-i*3200)
}));

const GOALS = [
  {id:1,name:"Retirement at 65",target:8_500_000,current:1_200_000,date:"2041",progress:14,color:"#C9922A",icon:"🏦",prob:78,gap:2400},
  {id:2,name:"TFSA Max Out",target:500_000,current:144_000,date:"2037",progress:29,color:"#4CAF7D",icon:"📈",prob:92,gap:3000},
  {id:3,name:"Education Fund",target:650_000,current:88_000,date:"2034",progress:14,color:"#5B8DEF",icon:"🎓",prob:65,gap:4500},
  {id:4,name:"Emergency Fund",target:120_000,current:45_000,date:"2026",progress:38,color:"#AB5CF7",icon:"🛟",prob:85,gap:6250},
];

const PRODUCTS = [
  {name:"Retirement Annuity",type:"RA",balance:480000,contribution:6500,growth:10.2,color:"#C9922A",icon:"🏦"},
  {name:"Tax-Free Savings",type:"TFSA",balance:144000,contribution:3000,growth:11.1,color:"#4CAF7D",icon:"📈"},
  {name:"Unit Trust — Balanced",type:"UNIT",balance:312000,contribution:4000,growth:9.8,color:"#5B8DEF",icon:"📊"},
  {name:"Term Life Cover",type:"LIFE",balance:0,contribution:1840,growth:0,color:"#AB5CF7",icon:"🛡️"},
  {name:"Home Loan",type:"DEBT",balance:780000,contribution:12500,growth:-11.5,color:"#E05C5C",icon:"🏠"},
  {name:"Money Market",type:"SAVE",balance:45000,contribution:2000,growth:8.5,color:"#E07B54",icon:"💰"},
];

const ADVISER_KPI = [
  {label:"Net Worth @ 65",value:"R 8.4M",delta:"+12.3%",color:"#C9922A"},
  {label:"Retirement Income",value:"R 52K/mo",delta:"78% prob",color:"#4CAF7D"},
  {label:"Tax Saving (RA)",value:"R 28,600/yr",delta:"Max utilised",color:"#5B8DEF"},
  {label:"Estate Net Value",value:"R 6.2M",delta:"Duty: R86k",color:"#AB5CF7"},
  {label:"TFSA Remaining",value:"R 356K",delta:"Life limit",color:"#E07B54"},
  {label:"Plan Score",value:"74 / 100",delta:"Adequate",color:"#C9922A"},
];

const COMPLIANCE_FLAGS = [
  {id:1,sev:"HIGH",desc:"Risk appetite questionnaire not on file",plan:"Andile Mokoena — Plan #2847",date:"18 Apr 2026"},
  {id:2,sev:"HIGH",desc:"Fee disclosure not signed by client",plan:"Sarah van Rooyen — Plan #2851",date:"19 Apr 2026"},
  {id:3,sev:"MEDIUM",desc:"Replacement advice form missing — RA restructure",plan:"James Sithole — Plan #2839",date:"15 Apr 2026"},
  {id:4,sev:"MEDIUM",desc:"Disability cover not discussed — 3 dependants on record",plan:"Priya Naidoo — Plan #2845",date:"17 Apr 2026"},
  {id:5,sev:"LOW",desc:"Product illustration uses assumptions outside ASISA range",plan:"Thabo Dlamini — Plan #2848",date:"18 Apr 2026"},
];

const EXEC_KPI = [
  {label:"Active Plans",value:"1,247",delta:"+89 this month",color:"#3B9EFF"},
  {label:"Plans Completed",value:"892",delta:"71.5% completion",color:"#22C55E"},
  {label:"AUM Modelled",value:"R 4.2B",delta:"+R 340M MoM",color:"#60BAFF"},
  {label:"FAIS Flags Open",value:"23",delta:"↓ 8 from last week",color:"#F59E0B"},
  {label:"Avg Plan Score",value:"71.2",delta:"Industry: 68.4",color:"#22C55E"},
  {label:"Active Advisers",value:"156",delta:"12 new this quarter",color:"#3B9EFF"},
];

const EXEC_PIPELINE = [
  {month:"Nov",plans:98,completed:71},
  {month:"Dec",plans:112,completed:84},
  {month:"Jan",plans:134,completed:102},
  {month:"Feb",plans:156,completed:118},
  {month:"Mar",plans:178,completed:139},
  {month:"Apr",plans:156,completed:121},
];

const TAX_DATA = [
  {bracket:"0–237k",rate:18,exposure:42678,color:"#4CAF7D"},
  {bracket:"237–370k",rate:26,exposure:34684,color:"#5B8DEF"},
  {bracket:"370–512k",rate:31,exposure:44142,color:"#C9922A"},
  {bracket:"512–673k",rate:36,exposure:28800,color:"#E07B54"},
  {bracket:"673k+",rate:39,exposure:0,color:"#AB5CF7"},
];

const AGENT_CHAT = [
  {role:"user",text:"Can my client retire comfortably at 62 instead of 65?"},
  {role:"agent",text:"Running Monte Carlo for retirement at age 62...\n\n✓ At 62: 68% probability of success (R42,300/month income)\n✓ At 65: 89% probability of success (R52,100/month income)\n\nThe 3-year gap reduces probability by 21 points, primarily due to sequence-of-returns risk in the early retirement window.\n\n💡 To achieve 80%+ success at 62, I recommend:\n• Increase RA contribution by R2,400/month (from R6,500 → R8,900)\n• Maintain living annuity drawdown at 4.5% (not current 6.2%)\n• TFSA fully maxed each year — currently R900/month underutilised\n\nShall I generate a scenario comparison PDF?"},
];

const fmtK = v => { const a=Math.abs(v); if(a>=1e9)return`R${(v/1e9).toFixed(1)}B`; if(a>=1e6)return`R${(v/1e6).toFixed(1)}M`; if(a>=1e3)return`R${(v/1e3).toFixed(0)}K`; return`R${v}`; };
const fmt2 = v => new Intl.NumberFormat("en-ZA",{style:"currency",currency:"ZAR",maximumFractionDigits:0}).format(v);

// ─── CUSTOM TOOLTIP ─────────────────────────────────────────────────────────
const ChartTip = ({active,payload,label,t}) => {
  if(!active||!payload?.length) return null;
  return (
    <div style={{background:t.surface,border:`1px solid ${t.border}`,borderRadius:8,padding:"10px 14px",fontSize:11,fontFamily:t.body}}>
      <div style={{color:t.accent,fontWeight:700,marginBottom:4}}>Year {label}</div>
      {payload.map((p,i)=>(
        <div key={i} style={{color:p.color,marginBottom:2}}>{p.name}: <span style={{color:t.text}}>{fmtK(p.value)}</span></div>
      ))}
    </div>
  );
};

// ─── RING CHART ──────────────────────────────────────────────────────────────
const Ring = ({value,color,size=72,stroke=8,label,sublabel,t}) => {
  const r = (size-stroke*2)/2;
  const circ = 2*Math.PI*r;
  const dash = (value/100)*circ;
  return (
    <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:4}}>
      <svg width={size} height={size}>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={t.dim} strokeWidth={stroke}/>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth={stroke}
          strokeDasharray={`${dash} ${circ}`} strokeLinecap="round"
          transform={`rotate(-90 ${size/2} ${size/2})`}/>
        <text x={size/2} y={size/2+1} textAnchor="middle" dominantBaseline="middle"
          fill={color} fontSize={size/5} fontWeight={700} fontFamily="sans-serif">{value}%</text>
      </svg>
      {label && <div style={{fontSize:10,color:t.text,fontFamily:t.body,textAlign:"center",fontWeight:600}}>{label}</div>}
      {sublabel && <div style={{fontSize:9,color:t.muted,fontFamily:t.body,textAlign:"center"}}>{sublabel}</div>}
    </div>
  );
};

// ─── PROBABILITY GAUGE ────────────────────────────────────────────────────────
const ProbGauge = ({value,t}) => {
  const color = value>=80?"#4CAF7D":value>=60?"#E8B84B":"#E05C5C";
  const label = value>=80?"ON TRACK":value>=60?"MONITOR":"AT RISK";
  return (
    <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:8}}>
      <Ring value={value} color={color} size={120} stroke={12} t={t}/>
      <div style={{background:`${color}22`,border:`1px solid ${color}44`,borderRadius:20,padding:"3px 14px",fontSize:11,color,fontFamily:t.body,fontWeight:700,letterSpacing:"0.1em"}}>{label}</div>
      <div style={{fontSize:11,color:t.muted,fontFamily:t.body}}>Probability of Success</div>
    </div>
  );
};

// ─── MAIN COMPONENT ────────────────────────────────────────────────────────
export default function SanlamCFEWireframe() {
  const [roleId, setRoleId] = useState("ADVISER");
  const [activeTab, setActiveTab] = useState(0);
  const [agentInput, setAgentInput] = useState("");
  const [chat, setChat] = useState(AGENT_CHAT);
  const [agentThinking, setAgentThinking] = useState(false);
  const [prevRole, setPrevRole] = useState(null);
  const [transitioning, setTransitioning] = useState(false);
  const chatRef = useRef(null);

  const t = ROLES[roleId];

  const switchRole = (id) => {
    if (id === roleId) return;
    setTransitioning(true);
    setTimeout(() => { setRoleId(id); setActiveTab(0); setTransitioning(false); }, 280);
  };

  useEffect(() => {
    if (chatRef.current) chatRef.current.scrollTop = chatRef.current.scrollHeight;
  }, [chat]);

  const sendMessage = () => {
    if (!agentInput.trim()) return;
    const msg = agentInput;
    setAgentInput("");
    setChat(c => [...c, {role:"user",text:msg}]);
    setAgentThinking(true);
    setTimeout(() => {
      setChat(c => [...c, {role:"agent",text:`Analysing "${msg}"...\n\nBased on the current plan for your client, I've run a full Monte Carlo projection (10,000 simulations). The key finding is that current asset allocation achieves a 74% probability of success at the stated retirement date.\n\n💡 Top 3 recommendations:\n1. Increase RA by R1,200/month → pushes success to 82%\n2. Reduce living annuity drawdown from 6.2% to 5.0%\n3. Full TFSA utilisation — R900/month gap identified\n\nWould you like me to generate the updated plan and draft an ROA?`}]);
      setAgentThinking(false);
    }, 1800);
  };

  // ── SHARED STYLES ──────────────────────────────────────────────────────────
  const APP = {
    minHeight:"100vh", background:t.bg, color:t.text, fontFamily:t.body,
    transition:"background 0.35s ease, color 0.35s ease",
    display:"flex", flexDirection:"column",
    opacity: transitioning ? 0 : 1,
    transform: transitioning ? "translateY(8px)" : "translateY(0)",
    transition: "opacity 0.28s ease, transform 0.28s ease, background 0.35s ease",
  };
  const HEADER = {
    background:t.headerBg, borderBottom:`1px solid ${t.border}`,
    padding:"0 24px", display:"flex", alignItems:"center", gap:20, height:64, flexShrink:0,
  };
  const BODY = { flex:1, display:"flex", overflow:"hidden" };
  const SIDEBAR = {
    width:220, background:t.surface, borderRight:`1px solid ${t.border}`,
    display:"flex", flexDirection:"column", flexShrink:0, overflowY:"auto",
  };
  const MAIN = { flex:1, overflowY:"auto", padding:"20px 24px" };
  const CARD = (extra={}) => ({
    background:t.card, border:`1px solid ${t.border}`, borderRadius:12,
    padding:"18px 20px", ...extra
  });
  const KPI_CARD = (color) => ({
    background:t.card, border:`1px solid ${color}33`, borderRadius:12,
    padding:"18px 20px", position:"relative", overflow:"hidden",
    flex:1, minWidth:140,
  });
  const TAB_BTN = (active) => ({
    padding:"8px 16px", borderRadius:6, border:"none", cursor:"pointer",
    fontFamily:t.body, fontSize:11, letterSpacing:"0.08em", textTransform:"uppercase",
    fontWeight: active?700:400,
    background: active?t.accent:"transparent",
    color: active?(t.id==="CLIENT"?"#fff":t.bg):t.muted,
    transition:"all 0.2s",
  });
  const NAV_ITEM = (active) => ({
    padding:"10px 16px", cursor:"pointer", display:"flex", alignItems:"center", gap:10,
    background: active?`${t.accent}18`:"transparent",
    borderLeft: active?`3px solid ${t.accent}`:"3px solid transparent",
    transition:"all 0.15s",
  });

  // ── ROLE ICONS FOR SIDEBAR ─────────────────────────────────────────────────
  const ADVISER_NAV = ["◈ Dashboard","⊞ Portfolio","∿ Monte Carlo","◎ Goals","⊕ Tax & Estate","⊘ Scenarios","✦ AI Agent","⊟ Outputs"];
  const CLIENT_NAV  = ["◉ My Plan","○ My Goals","◯ My Products","✧ Ask ARIA","↗ Share"];
  const ACTUARY_NAV = ["⬡ Engine","∿ Simulation","◫ Distribution","⊞ Raw Output","↓ Export"];
  const COMPLIANCE_NAV = ["⊞ Plan Review","⊟ Audit Log","⚑ FAIS Flags","✓ ROA Status","⊠ Reports"];
  const EXEC_NAV    = ["◆ Overview","⊞ Adviser Activity","◎ Portfolio Mix","⚠ Risk Alerts","✦ Intelligence"];

  const navItems = {ADVISER:ADVISER_NAV,CLIENT:CLIENT_NAV,ACTUARY:ACTUARY_NAV,COMPLIANCE:COMPLIANCE_NAV,EXECUTIVE:EXEC_NAV}[roleId];

  // ── RENDER TABS ────────────────────────────────────────────────────────────
  const renderContent = () => {
    if (roleId === "ADVISER") return renderAdviser();
    if (roleId === "CLIENT")  return renderClient();
    if (roleId === "ACTUARY") return renderActuary();
    if (roleId === "COMPLIANCE") return renderCompliance();
    if (roleId === "EXECUTIVE") return renderExecutive();
  };

  // ── ADVISER ───────────────────────────────────────────────────────────────
  const renderAdviser = () => {
    if (activeTab === 6) return renderAgentTab();
    if (activeTab === 2) return renderMonteCarlo();
    if (activeTab === 1) return renderPortfolio();
    if (activeTab === 3) return renderGoals();
    if (activeTab === 4) return renderTaxEstate();
    if (activeTab === 7) return renderOutputs();
    return (
      <>
        <div style={{display:"flex",gap:12,marginBottom:20,flexWrap:"wrap"}}>
          {ADVISER_KPI.map((k,i)=>(
            <div key={i} style={KPI_CARD(k.color)}>
              <div style={{position:"absolute",top:0,left:0,right:0,height:3,background:`linear-gradient(90deg,${k.color},${k.color}44)`}}/>
              <div style={{fontSize:10,letterSpacing:"0.15em",textTransform:"uppercase",color:t.muted,marginBottom:6,fontFamily:t.body}}>{k.label}</div>
              <div style={{fontSize:22,fontWeight:700,color:k.color,fontFamily:t.display,letterSpacing:"-0.02em"}}>{k.value}</div>
              <div style={{fontSize:11,color:t.muted,marginTop:3,fontFamily:t.body}}>{k.delta}</div>
            </div>
          ))}
        </div>
        <div style={{display:"grid",gridTemplateColumns:"1.6fr 1fr",gap:16,marginBottom:16}}>
          <div style={CARD()}>
            <div style={{fontSize:11,letterSpacing:"0.12em",textTransform:"uppercase",color:t.muted,marginBottom:14,fontFamily:t.body}}>Net Worth Trajectory — 25-Year Projection</div>
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={NW_DATA.filter((_,i)=>i%1===0)}>
                <defs>
                  <linearGradient id="ga" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#4CAF7D" stopOpacity={0.3}/><stop offset="95%" stopColor="#4CAF7D" stopOpacity={0}/></linearGradient>
                  <linearGradient id="gn" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor={t.accent} stopOpacity={0.4}/><stop offset="95%" stopColor={t.accent} stopOpacity={0}/></linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke={t.dim}/>
                <XAxis dataKey="year" stroke={t.dim} tick={{fill:t.muted,fontSize:10,fontFamily:t.body}}/>
                <YAxis stroke={t.dim} tick={{fill:t.muted,fontSize:10,fontFamily:t.body}} tickFormatter={fmtK}/>
                <Tooltip content={<ChartTip t={t}/>}/>
                <Area type="monotone" dataKey="assets" name="Assets" stroke="#4CAF7D" fill="url(#ga)" strokeWidth={1.5}/>
                <Area type="monotone" dataKey="netWorth" name="Net Worth" stroke={t.accent} fill="url(#gn)" strokeWidth={2}/>
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <div style={CARD()}>
            <div style={{fontSize:11,letterSpacing:"0.12em",textTransform:"uppercase",color:t.muted,marginBottom:16,fontFamily:t.body}}>Retirement Adequacy</div>
            <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:16}}>
              <ProbGauge value={78} t={t}/>
              <div style={{width:"100%",display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
                {[["Replacement Ratio","74%","#4CAF7D"],["Safe Drawdown","4.8%","#5B8DEF"],["Years of Income","28 yrs","#C9922A"],["Ruin Prob.","3.2%","#E05C5C"]].map(([l,v,c])=>(
                  <div key={l} style={{background:t.surface,borderRadius:8,padding:"8px 10px",border:`1px solid ${t.border}`}}>
                    <div style={{fontSize:9,color:t.muted,fontFamily:t.body,letterSpacing:"0.1em",textTransform:"uppercase"}}>{l}</div>
                    <div style={{fontSize:16,fontWeight:700,color:c,fontFamily:t.display}}>{v}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
        <div style={CARD()}>
          <div style={{fontSize:11,letterSpacing:"0.12em",textTransform:"uppercase",color:t.muted,marginBottom:14,fontFamily:t.body}}>Annual Cash Flow — Contributions vs Income</div>
          <ResponsiveContainer width="100%" height={140}>
            <ComposedChart data={CASH_FLOW}>
              <CartesianGrid strokeDasharray="3 3" stroke={t.dim}/>
              <XAxis dataKey="year" stroke={t.dim} tick={{fill:t.muted,fontSize:9,fontFamily:t.body}}/>
              <YAxis stroke={t.dim} tick={{fill:t.muted,fontSize:9,fontFamily:t.body}} tickFormatter={fmtK}/>
              <Tooltip content={<ChartTip t={t}/>}/>
              <ReferenceLine y={0} stroke={t.accent} strokeDasharray="4 4"/>
              <Bar dataKey="outflow" name="Outflows" fill={`${t.negative}44`} stroke={t.negative}/>
              <Bar dataKey="inflow" name="Inflows" fill={`${t.positive}44`} stroke={t.positive}/>
              <Line type="monotone" dataKey="net" name="Net Flow" stroke={t.accent} strokeWidth={2} dot={false}/>
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </>
    );
  };

  const renderMonteCarlo = () => (
    <>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:16,marginBottom:16}}>
        {[["Success Rate","78%","10,000 simulations","#4CAF7D"],["Median Outcome","R 8.4M","At retirement","#C9922A"],["Probability of Ruin","3.2%","Before age 90","#E05C5C"]].map(([l,v,sub,c])=>(
          <div key={l} style={KPI_CARD(c)}>
            <div style={{position:"absolute",top:0,left:0,right:0,height:3,background:`linear-gradient(90deg,${c},${c}44)`}}/>
            <div style={{fontSize:10,letterSpacing:"0.15em",textTransform:"uppercase",color:t.muted,marginBottom:6,fontFamily:t.body}}>{l}</div>
            <div style={{fontSize:32,fontWeight:700,color:c,fontFamily:t.display}}>{v}</div>
            <div style={{fontSize:11,color:t.muted,fontFamily:t.body}}>{sub}</div>
          </div>
        ))}
      </div>
      <div style={CARD({marginBottom:16})}>
        <div style={{fontSize:11,letterSpacing:"0.12em",textTransform:"uppercase",color:t.muted,marginBottom:4,fontFamily:t.body}}>Monte Carlo Fan Chart — 10,000 Simulation Paths — Wealth at Retirement</div>
        <div style={{fontSize:10,color:t.muted,marginBottom:14,fontFamily:t.body}}>Showing 10th / 25th / 50th / 75th / 90th percentile wealth trajectories</div>
        <ResponsiveContainer width="100%" height={260}>
          <AreaChart data={NW_DATA}>
            <defs>
              {[["p90","#4CAF7D",0.15],["p75","#4CAF7D",0.25],["p50",t.accent,0.5],["p25","#E07B54",0.3],["p10","#E05C5C",0.2]].map(([k,c,o])=>(
                <linearGradient key={k} id={`mc_${k}`} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={c} stopOpacity={o}/>
                  <stop offset="95%" stopColor={c} stopOpacity={0}/>
                </linearGradient>
              ))}
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke={t.dim}/>
            <XAxis dataKey="year" stroke={t.dim} tick={{fill:t.muted,fontSize:10,fontFamily:t.body}} label={{value:"Year",position:"insideBottom",offset:-2,fill:t.muted,fontSize:10}}/>
            <YAxis stroke={t.dim} tick={{fill:t.muted,fontSize:10,fontFamily:t.body}} tickFormatter={fmtK}/>
            <Tooltip content={<ChartTip t={t}/>}/>
            <Area type="monotone" dataKey="p90" name="90th %ile" stroke="#4CAF7D" fill="url(#mc_p90)" strokeWidth={1} strokeDasharray="4 4"/>
            <Area type="monotone" dataKey="p75" name="75th %ile" stroke="#4CAF7D" fill="url(#mc_p75)" strokeWidth={1.5}/>
            <Area type="monotone" dataKey="p50" name="Median" stroke={t.accent} fill="url(#mc_p50)" strokeWidth={2.5}/>
            <Area type="monotone" dataKey="p25" name="25th %ile" stroke="#E07B54" fill="url(#mc_p25)" strokeWidth={1.5}/>
            <Area type="monotone" dataKey="p10" name="10th %ile" stroke="#E05C5C" fill="url(#mc_p10)" strokeWidth={1} strokeDasharray="4 4"/>
          </AreaChart>
        </ResponsiveContainer>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16}}>
        <div style={CARD()}>
          <div style={{fontSize:11,letterSpacing:"0.12em",textTransform:"uppercase",color:t.muted,marginBottom:16,fontFamily:t.body}}>Probability of Success at Various Contribution Levels</div>
          {[["+R0/mo","78%",0.78],["+ R800/mo","81%",0.81],["+R1,600/mo","85%",0.85],["+R2,400/mo","89%",0.89],["+R4,000/mo","94%",0.94]].map(([label,prob,val])=>{
            const c = val>=0.85?"#4CAF7D":val>=0.75?"#C9922A":"#E05C5C";
            return (
              <div key={label} style={{display:"flex",alignItems:"center",gap:12,marginBottom:10}}>
                <div style={{width:90,fontSize:12,fontFamily:t.body,color:t.text}}>{label}</div>
                <div style={{flex:1,height:8,background:t.dim,borderRadius:4,overflow:"hidden"}}>
                  <div style={{height:"100%",width:`${val*100}%`,background:c,borderRadius:4,transition:"width 0.5s"}}/>
                </div>
                <div style={{width:40,fontSize:13,fontWeight:700,color:c,fontFamily:t.display,textAlign:"right"}}>{prob}</div>
              </div>
            );
          })}
        </div>
        <div style={CARD()}>
          <div style={{fontSize:11,letterSpacing:"0.12em",textTransform:"uppercase",color:t.muted,marginBottom:16,fontFamily:t.body}}>Probability of Ruin by Age</div>
          <ResponsiveContainer width="100%" height={180}>
            <LineChart data={[{age:70,ruin:1.2},{age:75,ruin:2.1},{age:80,ruin:3.2},{age:85,ruin:5.8},{age:90,ruin:9.4},{age:95,ruin:16.2}]}>
              <CartesianGrid strokeDasharray="3 3" stroke={t.dim}/>
              <XAxis dataKey="age" stroke={t.dim} tick={{fill:t.muted,fontSize:10,fontFamily:t.body}}/>
              <YAxis stroke={t.dim} tick={{fill:t.muted,fontSize:10,fontFamily:t.body}} unit="%"/>
              <Tooltip/>
              <Line type="monotone" dataKey="ruin" name="Ruin %" stroke={t.negative} strokeWidth={2} dot={{fill:t.negative,r:3}}/>
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </>
  );

  const renderPortfolio = () => (
    <>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
        <div style={{fontSize:14,fontWeight:700,color:t.text,fontFamily:t.display}}>Active Portfolio — 6 Products</div>
        <button style={{background:t.accent,color:t.bg,border:"none",borderRadius:8,padding:"8px 18px",cursor:"pointer",fontSize:12,fontWeight:700,fontFamily:t.body}}>+ Add Product</button>
      </div>
      {PRODUCTS.map((p,i)=>(
        <div key={i} style={{...CARD({marginBottom:10}),display:"flex",alignItems:"center",gap:16}}>
          <div style={{width:40,height:40,borderRadius:10,background:`${p.color}22`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,flexShrink:0}}>{p.icon}</div>
          <div style={{flex:1}}>
            <div style={{fontSize:13,fontWeight:600,color:t.text,fontFamily:t.body}}>{p.name}</div>
            <div style={{fontSize:10,color:t.muted,fontFamily:t.body,marginTop:2}}>{p.type} · {p.growth>0?`${p.growth}% p.a. growth`:`${Math.abs(p.growth)}% interest rate`}</div>
          </div>
          <div style={{textAlign:"right",minWidth:100}}>
            <div style={{fontSize:11,color:t.muted,fontFamily:t.body}}>Current Value</div>
            <div style={{fontSize:16,fontWeight:700,color:p.color,fontFamily:t.display}}>{p.balance>0?fmt2(p.balance):"Cover"}</div>
          </div>
          <div style={{textAlign:"right",minWidth:100}}>
            <div style={{fontSize:11,color:t.muted,fontFamily:t.body}}>{p.type==="DEBT"?"Monthly Repayment":"Monthly Contribution"}</div>
            <div style={{fontSize:14,fontWeight:600,color:t.text,fontFamily:t.body}}>{fmt2(p.contribution)}</div>
          </div>
          <div style={{background:`${p.color}22`,border:`1px solid ${p.color}44`,borderRadius:6,padding:"4px 12px",fontSize:11,color:p.color,fontFamily:t.body,fontWeight:700,whiteSpace:"nowrap"}}>{p.type}</div>
        </div>
      ))}
      <div style={{...CARD({marginTop:16}),display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:16}}>
        {[["Total Assets","R 1,029,000","#4CAF7D"],["Total Liabilities","R 780,000","#E05C5C"],["Net Position","R 249,000","#C9922A"]].map(([l,v,c])=>(
          <div key={l} style={{textAlign:"center"}}>
            <div style={{fontSize:10,color:t.muted,fontFamily:t.body,letterSpacing:"0.12em",textTransform:"uppercase",marginBottom:4}}>{l}</div>
            <div style={{fontSize:24,fontWeight:700,color:c,fontFamily:t.display}}>{v}</div>
          </div>
        ))}
      </div>
    </>
  );

  const renderGoals = () => (
    <>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16,marginBottom:16}}>
        {GOALS.map(g=>(
          <div key={g.id} style={{...CARD(),borderLeft:`4px solid ${g.color}`}}>
            <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:12}}>
              <div style={{display:"flex",alignItems:"center",gap:10}}>
                <span style={{fontSize:22}}>{g.icon}</span>
                <div>
                  <div style={{fontSize:13,fontWeight:700,color:t.text,fontFamily:t.body}}>{g.name}</div>
                  <div style={{fontSize:10,color:t.muted,fontFamily:t.body}}>Target: {fmt2(g.target)} by {g.date}</div>
                </div>
              </div>
              <Ring value={g.prob} color={g.prob>=80?"#4CAF7D":g.prob>=65?"#C9922A":"#E05C5C"} size={60} stroke={6} t={t}/>
            </div>
            <div style={{marginBottom:8}}>
              <div style={{display:"flex",justifyContent:"space-between",fontSize:10,color:t.muted,fontFamily:t.body,marginBottom:4}}>
                <span>{fmt2(g.current)} current</span><span>{g.progress}% funded</span>
              </div>
              <div style={{height:8,background:t.dim,borderRadius:4,overflow:"hidden"}}>
                <div style={{height:"100%",width:`${g.progress}%`,background:`linear-gradient(90deg,${g.color},${g.color}88)`,borderRadius:4}}/>
              </div>
            </div>
            <div style={{background:`${g.color}11`,border:`1px solid ${g.color}33`,borderRadius:8,padding:"8px 12px"}}>
              <div style={{fontSize:10,color:t.muted,fontFamily:t.body}}>To close gap at 80% confidence:</div>
              <div style={{fontSize:14,fontWeight:700,color:g.color,fontFamily:t.display}}>+ {fmt2(g.gap)}/month additional</div>
            </div>
          </div>
        ))}
      </div>
    </>
  );

  const renderTaxEstate = () => (
    <>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16,marginBottom:16}}>
        <div style={CARD()}>
          <div style={{fontSize:11,letterSpacing:"0.12em",textTransform:"uppercase",color:t.muted,marginBottom:16,fontFamily:t.body}}>Tax Exposure by Bracket (Current Year)</div>
          {TAX_DATA.map((b,i)=>(
            <div key={i} style={{display:"flex",alignItems:"center",gap:12,marginBottom:10}}>
              <div style={{width:64,fontSize:10,color:t.muted,fontFamily:t.body}}>{b.bracket}</div>
              <div style={{fontSize:11,fontWeight:700,color:b.color,fontFamily:t.body,width:28}}>{b.rate}%</div>
              <div style={{flex:1,height:10,background:t.dim,borderRadius:4,overflow:"hidden"}}>
                <div style={{height:"100%",width:`${(b.exposure/50000)*100}%`,background:b.color,borderRadius:4}}/>
              </div>
              <div style={{width:60,fontSize:11,color:t.text,fontFamily:t.body,textAlign:"right"}}>{b.exposure>0?fmt2(b.exposure):"—"}</div>
            </div>
          ))}
          <div style={{borderTop:`1px solid ${t.border}`,marginTop:12,paddingTop:12,display:"flex",justifyContent:"space-between"}}>
            <div style={{fontSize:12,color:t.muted,fontFamily:t.body}}>Total Tax Liability</div>
            <div style={{fontSize:16,fontWeight:700,color:t.negative,fontFamily:t.display}}>R 150,104</div>
          </div>
          <div style={{display:"flex",justifyContent:"space-between",marginTop:6}}>
            <div style={{fontSize:12,color:t.muted,fontFamily:t.body}}>RA Tax Saving</div>
            <div style={{fontSize:14,fontWeight:700,color:t.positive,fontFamily:t.display}}>- R 28,600</div>
          </div>
        </div>
        <div style={CARD()}>
          <div style={{fontSize:11,letterSpacing:"0.12em",textTransform:"uppercase",color:t.muted,marginBottom:16,fontFamily:t.body}}>Estate Summary</div>
          {[["Gross Estate Value","R 1,809,000","#C9922A"],["RA & Pension (excl.)","- R 480,000","#4CAF7D"],["Life Cover (excl.)","- R 2,000,000","#4CAF7D"],["Net Dutiable Estate","R 329,000","#5B8DEF"],["Less Abatement","- R 3,500,000","#4CAF7D"],["Estate Duty","R 0","#4CAF7D"]].map(([l,v,c])=>(
            <div key={l} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"7px 0",borderBottom:`1px solid ${t.dim}`}}>
              <div style={{fontSize:12,color:t.text,fontFamily:t.body}}>{l}</div>
              <div style={{fontSize:13,fontWeight:700,color:c,fontFamily:t.display}}>{v}</div>
            </div>
          ))}
          <div style={{marginTop:12,background:`${t.positive}11`,border:`1px solid ${t.positive}33`,borderRadius:8,padding:"10px 14px"}}>
            <div style={{fontSize:11,color:t.positive,fontFamily:t.body,fontWeight:700}}>✓ Estate is within abatement — no duty payable</div>
            <div style={{fontSize:10,color:t.muted,fontFamily:t.body,marginTop:3}}>Beneficiary nominations on RA and life cover are correctly structured</div>
          </div>
        </div>
      </div>
      <div style={CARD()}>
        <div style={{fontSize:11,letterSpacing:"0.12em",textTransform:"uppercase",color:t.muted,marginBottom:12,fontFamily:t.body}}>Tax Optimisation Opportunities</div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:12}}>
          {[
            ["RA Headroom","R 0","Fully utilised ✓","#4CAF7D"],
            ["TFSA Annual Gap","R 900/mo","Utilising R2,100 of R3,000","#C9922A"],
            ["Interest Exemption","R 23,800 used","R 0 remaining","#5B8DEF"],
          ].map(([l,v,sub,c])=>(
            <div key={l} style={{background:t.surface,border:`1px solid ${c}33`,borderRadius:8,padding:"12px 14px"}}>
              <div style={{fontSize:10,color:t.muted,fontFamily:t.body,letterSpacing:"0.1em",textTransform:"uppercase",marginBottom:4}}>{l}</div>
              <div style={{fontSize:16,fontWeight:700,color:c,fontFamily:t.display}}>{v}</div>
              <div style={{fontSize:10,color:t.muted,fontFamily:t.body,marginTop:2}}>{sub}</div>
            </div>
          ))}
        </div>
      </div>
    </>
  );

  const renderOutputs = () => (
    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:16}}>
      {[
        {icon:"📄",title:"PDF Plan Report",desc:"13-section branded Sanlam document. Includes charts, projections, ROA, and all FAIS disclosures.",actions:["Generate PDF","Preview","Schedule"],color:"#C9922A"},
        {icon:"✉️",title:"Email to Client",desc:"HTML rich email with key plan metrics embedded. PDF attached. POPIA-compliant unsubscribe.",actions:["Send Now","Preview Email","Schedule Send"],color:"#5B8DEF"},
        {icon:"💬",title:"WhatsApp Delivery",desc:"Send plan summary, full PDF, or trigger interactive bot session. Requires client consent.",actions:["Summary Message","Full Report","Enable Bot"],color:"#4CAF7D"},
      ].map(o=>(
        <div key={o.title} style={{...CARD(),display:"flex",flexDirection:"column",gap:12,borderTop:`4px solid ${o.color}`}}>
          <div style={{fontSize:36,textAlign:"center",marginTop:4}}>{o.icon}</div>
          <div style={{textAlign:"center"}}>
            <div style={{fontSize:14,fontWeight:700,color:t.text,fontFamily:t.display}}>{o.title}</div>
            <div style={{fontSize:11,color:t.muted,fontFamily:t.body,marginTop:6,lineHeight:1.6}}>{o.desc}</div>
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:8,marginTop:"auto"}}>
            {o.actions.map(a=>(
              <button key={a} style={{background:o.actions.indexOf(a)===0?o.color:`${o.color}22`,color:o.actions.indexOf(a)===0?(t.id==="CLIENT"?"#fff":t.bg):o.color,border:`1px solid ${o.color}44`,borderRadius:8,padding:"9px",cursor:"pointer",fontSize:12,fontWeight:600,fontFamily:t.body}}>{a}</button>
            ))}
          </div>
        </div>
      ))}
    </div>
  );

  // ── AI AGENT ─────────────────────────────────────────────────────────────
  const renderAgentTab = () => (
    <div style={{display:"grid",gridTemplateColumns:"1fr 340px",gap:16,height:"calc(100vh - 160px)"}}>
      <div style={{...CARD(),display:"flex",flexDirection:"column",height:"100%"}}>
        <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:16,paddingBottom:12,borderBottom:`1px solid ${t.border}`}}>
          <div style={{width:36,height:36,borderRadius:"50%",background:`linear-gradient(135deg,${t.accent},${t.accent2})`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:18}}>✦</div>
          <div>
            <div style={{fontSize:14,fontWeight:700,color:t.text,fontFamily:t.display}}>ARIA — AI Planning Agent</div>
            <div style={{fontSize:10,color:t.positive,fontFamily:t.body}}>● Online · Planning Mode · Andile Mokoena's Plan</div>
          </div>
          <div style={{marginLeft:"auto",fontSize:11,color:t.muted,fontFamily:t.body}}>10,000 simulations ready</div>
        </div>
        <div ref={chatRef} style={{flex:1,overflowY:"auto",display:"flex",flexDirection:"column",gap:14,paddingRight:4}}>
          {chat.map((m,i)=>(
            <div key={i} style={{display:"flex",flexDirection:m.role==="user"?"row-reverse":"row",gap:10,alignItems:"flex-start"}}>
              <div style={{width:30,height:30,borderRadius:"50%",background:m.role==="user"?t.dim:`linear-gradient(135deg,${t.accent},${t.accent2})`,flexShrink:0,display:"flex",alignItems:"center",justifyContent:"center",fontSize:12,color:m.role==="user"?t.muted:t.bg,fontWeight:700,fontFamily:t.body}}>
                {m.role==="user"?"A":"✦"}
              </div>
              <div style={{maxWidth:"75%",background:m.role==="user"?t.surface:t.card,border:`1px solid ${m.role==="user"?t.border:`${t.accent}44`}`,borderRadius:m.role==="user"?"12px 4px 12px 12px":"4px 12px 12px 12px",padding:"10px 14px"}}>
                <div style={{fontSize:12,color:t.text,fontFamily:t.body,lineHeight:1.7,whiteSpace:"pre-line"}}>{m.text}</div>
              </div>
            </div>
          ))}
          {agentThinking && (
            <div style={{display:"flex",gap:10,alignItems:"flex-start"}}>
              <div style={{width:30,height:30,borderRadius:"50%",background:`linear-gradient(135deg,${t.accent},${t.accent2})`,flexShrink:0,display:"flex",alignItems:"center",justifyContent:"center",fontSize:12,color:t.bg,fontWeight:700}}>✦</div>
              <div style={{background:t.card,border:`1px solid ${t.accent}44`,borderRadius:"4px 12px 12px 12px",padding:"14px 18px"}}>
                <div style={{display:"flex",gap:6}}>
                  {[0,1,2].map(i=>(
                    <div key={i} style={{width:8,height:8,borderRadius:"50%",background:t.accent,animation:`pulse 1.2s ease-in-out ${i*0.2}s infinite`,opacity:0.7}}/>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
        <div style={{display:"flex",gap:8,marginTop:12,paddingTop:12,borderTop:`1px solid ${t.border}`}}>
          <input value={agentInput} onChange={e=>setAgentInput(e.target.value)}
            onKeyDown={e=>e.key==="Enter"&&sendMessage()}
            placeholder="Ask ARIA anything about this plan…"
            style={{flex:1,background:t.surface,border:`1px solid ${t.border}`,borderRadius:10,padding:"10px 14px",color:t.text,fontFamily:t.body,fontSize:13,outline:"none"}}/>
          <button onClick={sendMessage}
            style={{background:t.accent,color:t.bg,border:"none",borderRadius:10,padding:"10px 20px",cursor:"pointer",fontSize:13,fontWeight:700,fontFamily:t.body}}>
            Send ↑
          </button>
        </div>
      </div>
      <div style={{display:"flex",flexDirection:"column",gap:12}}>
        <div style={CARD()}>
          <div style={{fontSize:10,letterSpacing:"0.12em",textTransform:"uppercase",color:t.muted,marginBottom:10,fontFamily:t.body}}>Quick Actions</div>
          {["Run Retirement at 62 Scenario","Maximise TFSA Contribution","Generate FAIS ROA Draft","Compare 3 Scenarios","Check Estate Structure","Send Summary to Client"].map(a=>(
            <button key={a} onClick={()=>{setAgentInput(a);}}
              style={{display:"block",width:"100%",textAlign:"left",background:t.surface,border:`1px solid ${t.border}`,borderRadius:8,padding:"8px 12px",marginBottom:6,cursor:"pointer",fontSize:11,color:t.text,fontFamily:t.body,transition:"all 0.15s"}}>
              → {a}
            </button>
          ))}
        </div>
        <div style={CARD()}>
          <div style={{fontSize:10,letterSpacing:"0.12em",textTransform:"uppercase",color:t.muted,marginBottom:10,fontFamily:t.body}}>Active Plan Context</div>
          {[["Client","Andile Mokoena"],["Age","42"],["Plan #","CFE-2847"],["Last Updated","Today 09:14"],["Products","6 active"],["Score","74/100"]].map(([l,v])=>(
            <div key={l} style={{display:"flex",justifyContent:"space-between",padding:"5px 0",borderBottom:`1px solid ${t.dim}`,fontSize:11}}>
              <span style={{color:t.muted,fontFamily:t.body}}>{l}</span>
              <span style={{color:t.text,fontFamily:t.body,fontWeight:600}}>{v}</span>
            </div>
          ))}
        </div>
      </div>
      <style>{`@keyframes pulse{0%,100%{opacity:0.3}50%{opacity:1}}`}</style>
    </div>
  );

  // ── CLIENT ──────────────────────────────────────────────────────────────
  const renderClient = () => {
    if (activeTab === 3) return renderClientARIA();
    return (
      <div style={{maxWidth:680,margin:"0 auto"}}>
        <div style={{textAlign:"center",marginBottom:32}}>
          <div style={{fontSize:36,fontFamily:t.display,fontWeight:700,color:t.text,marginBottom:8}}>Good morning, Andile 👋</div>
          <div style={{fontSize:18,color:t.muted,fontFamily:t.body}}>Your financial plan is looking healthy</div>
        </div>
        <div style={{background:`linear-gradient(135deg,${t.accent},${t.accent2})`,borderRadius:20,padding:28,marginBottom:24,color:"#fff",textAlign:"center"}}>
          <div style={{fontSize:14,fontFamily:t.body,marginBottom:4,opacity:0.85}}>Projected Retirement Income</div>
          <div style={{fontSize:48,fontFamily:t.display,fontWeight:700}}>R 52,100/mo</div>
          <div style={{fontSize:14,fontFamily:t.body,marginTop:4,opacity:0.85}}>At age 65 — in today's money</div>
          <div style={{marginTop:16,background:"rgba(255,255,255,0.2)",borderRadius:12,padding:"10px 20px",display:"inline-block"}}>
            <div style={{fontSize:13,fontFamily:t.body}}>78% chance of not running out of money ✓</div>
          </div>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16,marginBottom:24}}>
          {GOALS.slice(0,2).map(g=>(
            <div key={g.id} style={{background:t.surface,border:`2px solid ${g.color}44`,borderRadius:16,padding:20}}>
              <div style={{fontSize:20,marginBottom:8}}>{g.icon}</div>
              <div style={{fontSize:14,fontWeight:700,color:t.text,fontFamily:t.body,marginBottom:4}}>{g.name}</div>
              <div style={{height:10,background:t.dim,borderRadius:5,overflow:"hidden",marginBottom:8}}>
                <div style={{height:"100%",width:`${g.progress}%`,background:g.color,borderRadius:5}}/>
              </div>
              <div style={{fontSize:13,color:t.muted,fontFamily:t.body}}>{g.progress}% funded · Target {g.date}</div>
            </div>
          ))}
        </div>
        <div style={{background:t.surface,border:`1px solid ${t.border}`,borderRadius:16,padding:20}}>
          <div style={{fontSize:14,fontWeight:700,color:t.text,fontFamily:t.body,marginBottom:14}}>💡 Your adviser suggests:</div>
          {["Top up your Tax-Free Savings by R900/month — it's tax-free growth!","Your RA is on track — keep contributing R6,500/month","Your home loan will be paid off by 2038 at current rate"].map((s,i)=>(
            <div key={i} style={{display:"flex",gap:12,alignItems:"flex-start",padding:"10px 0",borderBottom:`1px solid ${t.dim}`}}>
              <div style={{width:24,height:24,borderRadius:"50%",background:`${t.accent}22`,color:t.accent,display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:700,flexShrink:0,fontFamily:t.body}}>{i+1}</div>
              <div style={{fontSize:13,color:t.text,fontFamily:t.body,lineHeight:1.6}}>{s}</div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderClientARIA = () => (
    <div style={{maxWidth:680,margin:"0 auto",display:"flex",flexDirection:"column",height:"calc(100vh - 160px)"}}>
      <div style={{textAlign:"center",marginBottom:20}}>
        <div style={{width:60,height:60,borderRadius:"50%",background:`linear-gradient(135deg,${t.accent},${t.accent2})`,margin:"0 auto 10px",display:"flex",alignItems:"center",justifyContent:"center",fontSize:26}}>✦</div>
        <div style={{fontSize:20,fontWeight:700,color:t.text,fontFamily:t.display}}>Ask ARIA</div>
        <div style={{fontSize:13,color:t.muted,fontFamily:t.body}}>Your personal financial planning assistant</div>
      </div>
      <div style={{flex:1,overflowY:"auto",background:t.surface,borderRadius:16,padding:20,marginBottom:16,display:"flex",flexDirection:"column",gap:14}}>
        <div style={{background:`${t.accent}11`,border:`1px solid ${t.accent}33`,borderRadius:12,padding:"12px 16px"}}>
          <div style={{fontSize:13,color:t.text,fontFamily:t.body,lineHeight:1.7}}>Hi Andile! I'm ARIA, your financial planning assistant. I can answer questions about your plan in plain language. What would you like to know?</div>
        </div>
        {["Can I afford to retire at 62?","How much tax am I saving?","What happens to my money when I die?","Am I saving enough?"].map(q=>(
          <button key={q} onClick={()=>setAgentInput(q)} style={{background:t.card,border:`1px solid ${t.border}`,borderRadius:12,padding:"12px 16px",cursor:"pointer",textAlign:"left",fontSize:13,color:t.text,fontFamily:t.body}}>
            💬 {q}
          </button>
        ))}
      </div>
      <div style={{display:"flex",gap:8}}>
        <input value={agentInput} onChange={e=>setAgentInput(e.target.value)} onKeyDown={e=>e.key==="Enter"&&sendMessage()} placeholder="Ask me anything…" style={{flex:1,background:t.surface,border:`2px solid ${t.border}`,borderRadius:12,padding:"12px 16px",color:t.text,fontFamily:t.body,fontSize:14,outline:"none"}}/>
        <button onClick={sendMessage} style={{background:t.accent,color:"#fff",border:"none",borderRadius:12,padding:"12px 20px",cursor:"pointer",fontSize:14,fontWeight:700,fontFamily:t.body}}>→</button>
      </div>
    </div>
  );

  // ── ACTUARY ──────────────────────────────────────────────────────────────
  const renderActuary = () => (
    <div style={{fontFamily:t.mono}}>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr 1fr",gap:8,marginBottom:16}}>
        {[["ENGINE_VER","CFE_v5.0.1","#00FF88"],["SEED","0xA3F2B1C7","#00FF88"],["PATHS","10,000","#00FF88"],["DURATION","7.24s","#00FF88"]].map(([k,v,c])=>(
          <div key={k} style={{background:t.card,border:`1px solid ${c}22`,borderRadius:6,padding:"10px 14px"}}>
            <div style={{fontSize:9,color:t.muted,letterSpacing:"0.2em"}}>{k}</div>
            <div style={{fontSize:16,fontWeight:700,color:c,marginTop:2}}>{v}</div>
          </div>
        ))}
      </div>
      <div style={{...CARD({marginBottom:12})}}>
        <div style={{fontSize:10,color:t.accent,letterSpacing:"0.2em",marginBottom:10}}>SIMULATION_OUTPUT :: PERCENTILE_DISTRIBUTION</div>
        <ResponsiveContainer width="100%" height={200}>
          <AreaChart data={NW_DATA}>
            <defs>
              <linearGradient id="ap90" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#00FF88" stopOpacity={0.08}/><stop offset="1" stopColor="#00FF88" stopOpacity={0}/></linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="2 4" stroke="#1A2A20"/>
            <XAxis dataKey="year" stroke="#1A2A20" tick={{fill:"#406050",fontSize:9,fontFamily:t.mono}}/>
            <YAxis stroke="#1A2A20" tick={{fill:"#406050",fontSize:9,fontFamily:t.mono}} tickFormatter={fmtK}/>
            <Tooltip content={<ChartTip t={t}/>}/>
            <Area type="monotone" dataKey="p90" stroke="#00FF88" fill="url(#ap90)" strokeWidth={1} name="P90"/>
            <Area type="monotone" dataKey="p50" stroke="#00CC66" fill="none" strokeWidth={1.5} name="P50" strokeDasharray="4 2"/>
            <Area type="monotone" dataKey="p10" stroke="#FF4466" fill="none" strokeWidth={1} name="P10" strokeDasharray="2 2"/>
          </AreaChart>
        </ResponsiveContainer>
      </div>
      <div style={{...CARD(),overflow:"auto"}}>
        <div style={{fontSize:10,color:t.accent,letterSpacing:"0.2em",marginBottom:10}}>RAW_OUTPUT :: CASH_FLOW_MATRIX [YEAR × VARIABLE]</div>
        <table style={{width:"100%",borderCollapse:"collapse",fontSize:11,fontFamily:t.mono}}>
          <thead>
            <tr>{["YR","ASSETS","LIAB","NET_WORTH","CF_OUT","CF_IN","TAX","PROB_SUCCESS"].map(h=>(
              <th key={h} style={{padding:"6px 10px",background:"#1A2A20",color:t.accent,fontSize:9,letterSpacing:"0.12em",textAlign:"right",borderBottom:`1px solid ${t.border}`}}>{h}</th>
            ))}</tr>
          </thead>
          <tbody>
            {NW_DATA.slice(0,10).map((d,i)=>(
              <tr key={i} style={{background:i%2===0?t.card:t.surface}}>
                {[d.year,fmtK(d.assets),fmtK(d.liabilities),fmtK(d.netWorth),fmtK(148000+i*3200),"—",fmtK(150104),`${(62+i*1.4).toFixed(1)}%`].map((v,j)=>(
                  <td key={j} style={{padding:"5px 10px",color:j===0?t.accent:t.text,textAlign:"right",borderBottom:`1px solid ${t.dim}`,fontSize:10}}>{v}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  // ── COMPLIANCE ────────────────────────────────────────────────────────────
  const renderCompliance = () => (
    <>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr 1fr",gap:12,marginBottom:20}}>
        {[["Total Plans Reviewed","1,247",""],["FAIS Compliant","1,224","✓ 98.1%","#155724","#D4EDDA"],["Flags Open","23","Needs Action","#856404","#FFF3CD"],["High Severity","2","Urgent","#721C24","#F8D7DA"]].map(([l,v,s,tc,bg])=>(
          <div key={l} style={{background:bg||t.surface,border:`1px solid ${tc||t.border}`,borderRadius:10,padding:"16px 18px"}}>
            <div style={{fontSize:10,letterSpacing:"0.12em",textTransform:"uppercase",color:tc||t.muted,fontFamily:t.body,marginBottom:6}}>{l}</div>
            <div style={{fontSize:28,fontWeight:700,color:tc||t.text,fontFamily:t.display}}>{v}</div>
            {s&&<div style={{fontSize:11,color:tc||t.muted,fontFamily:t.body,marginTop:3}}>{s}</div>}
          </div>
        ))}
      </div>
      <div style={{background:t.surface,border:`1px solid ${t.border}`,borderRadius:12,overflow:"hidden",marginBottom:16}}>
        <div style={{background:"#343A40",padding:"12px 18px",display:"grid",gridTemplateColumns:"80px 1fr 1fr 100px 100px",gap:10}}>
          {["SEV","FAIS FLAG","PLAN / ADVISER","DATE","ACTION"].map(h=>(
            <div key={h} style={{fontSize:10,letterSpacing:"0.15em",color:"#ADB5BD",fontFamily:t.body,textTransform:"uppercase"}}>{h}</div>
          ))}
        </div>
        {COMPLIANCE_FLAGS.map((f,i)=>{
          const sevColor = f.sev==="HIGH"?"#721C24":f.sev==="MEDIUM"?"#856404":"#0C5460";
          const sevBg = f.sev==="HIGH"?"#F8D7DA":f.sev==="MEDIUM"?"#FFF3CD":"#D1ECF1";
          return (
            <div key={i} style={{display:"grid",gridTemplateColumns:"80px 1fr 1fr 100px 100px",gap:10,padding:"12px 18px",borderTop:`1px solid ${t.border}`,background:i%2===0?t.surface:t.dim,alignItems:"center"}}>
              <div style={{background:sevBg,color:sevColor,borderRadius:4,padding:"2px 8px",fontSize:10,fontWeight:700,fontFamily:t.body,textAlign:"center"}}>{f.sev}</div>
              <div style={{fontSize:12,color:t.text,fontFamily:t.body}}>{f.desc}</div>
              <div style={{fontSize:11,color:t.muted,fontFamily:t.body}}>{f.plan}</div>
              <div style={{fontSize:11,color:t.muted,fontFamily:t.body}}>{f.date}</div>
              <button style={{background:"transparent",border:`1px solid ${t.border}`,borderRadius:6,padding:"4px 10px",cursor:"pointer",fontSize:10,color:t.accent,fontFamily:t.body}}>Review →</button>
            </div>
          );
        })}
      </div>
    </>
  );

  // ── EXECUTIVE ─────────────────────────────────────────────────────────────
  const renderExecutive = () => (
    <>
      <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12,marginBottom:16}}>
        {EXEC_KPI.map((k,i)=>(
          <div key={i} style={{...CARD(),borderTop:`3px solid ${k.color}`,position:"relative"}}>
            <div style={{fontSize:10,letterSpacing:"0.18em",textTransform:"uppercase",color:t.muted,marginBottom:8,fontFamily:t.body}}>{k.label}</div>
            <div style={{fontSize:32,fontWeight:900,color:k.color,fontFamily:t.display,letterSpacing:"-0.03em"}}>{k.value}</div>
            <div style={{fontSize:11,color:t.muted,marginTop:4,fontFamily:t.body}}>{k.delta}</div>
          </div>
        ))}
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1.5fr 1fr",gap:16,marginBottom:16}}>
        <div style={CARD()}>
          <div style={{fontSize:11,letterSpacing:"0.12em",textTransform:"uppercase",color:t.muted,marginBottom:14,fontFamily:t.body}}>Plan Activity — Last 6 Months</div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={EXEC_PIPELINE}>
              <CartesianGrid strokeDasharray="3 3" stroke={t.dim}/>
              <XAxis dataKey="month" stroke={t.dim} tick={{fill:t.muted,fontSize:10,fontFamily:t.body}}/>
              <YAxis stroke={t.dim} tick={{fill:t.muted,fontSize:10,fontFamily:t.body}}/>
              <Tooltip/>
              <Bar dataKey="plans" name="Plans Created" fill={`${t.accent}55`} stroke={t.accent} radius={[4,4,0,0]}/>
              <Bar dataKey="completed" name="Completed" fill={`${t.positive}55`} stroke={t.positive} radius={[4,4,0,0]}/>
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div style={CARD()}>
          <div style={{fontSize:11,letterSpacing:"0.12em",textTransform:"uppercase",color:t.muted,marginBottom:16,fontFamily:t.body}}>Portfolio AUM by Product Category</div>
          {[["Retirement Products","R 1.8B",43,"#C9922A"],["Investments","R 1.1B",26,"#5B8DEF"],["Savings","R 680M",16,"#4CAF7D"],["Risk / Life Cover","R 420M",10,"#AB5CF7"],["Debt Products","R 200M",5,"#E05C5C"]].map(([cat,v,pct,c])=>(
            <div key={cat} style={{marginBottom:10}}>
              <div style={{display:"flex",justifyContent:"space-between",fontSize:11,fontFamily:t.body,marginBottom:4}}>
                <span style={{color:t.text}}>{cat}</span>
                <span style={{color:c,fontWeight:700}}>{v}</span>
              </div>
              <div style={{height:6,background:t.dim,borderRadius:3}}>
                <div style={{height:"100%",width:`${pct*2}%`,background:c,borderRadius:3}}/>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16}}>
        <div style={CARD()}>
          <div style={{fontSize:11,letterSpacing:"0.12em",textTransform:"uppercase",color:t.muted,marginBottom:14,fontFamily:t.body}}>Top Performing Advisers — This Month</div>
          {[["Nomsa Dlamini","Cape Town","32 plans","R 42M AUM","#22C55E"],["Sipho Ndlovu","Johannesburg","28 plans","R 38M AUM","#22C55E"],["Anita van Wyk","Pretoria","24 plans","R 29M AUM","#3B9EFF"],["James Moyo","Durban","19 plans","R 22M AUM","#3B9EFF"]].map(([name,branch,plans,aum,c])=>(
            <div key={name} style={{display:"flex",alignItems:"center",gap:12,padding:"8px 0",borderBottom:`1px solid ${t.dim}`}}>
              <div style={{width:32,height:32,borderRadius:"50%",background:`${c}22`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,fontWeight:700,color:c,fontFamily:t.body}}>{name[0]}</div>
              <div style={{flex:1}}>
                <div style={{fontSize:12,fontWeight:700,color:t.text,fontFamily:t.body}}>{name}</div>
                <div style={{fontSize:10,color:t.muted,fontFamily:t.body}}>{branch}</div>
              </div>
              <div style={{textAlign:"right"}}>
                <div style={{fontSize:11,color:c,fontWeight:700,fontFamily:t.body}}>{plans}</div>
                <div style={{fontSize:10,color:t.muted,fontFamily:t.body}}>{aum}</div>
              </div>
            </div>
          ))}
        </div>
        <div style={CARD()}>
          <div style={{fontSize:11,letterSpacing:"0.12em",textTransform:"uppercase",color:t.muted,marginBottom:14,fontFamily:t.body}}>Net Worth Trajectory — Portfolio View</div>
          <ResponsiveContainer width="100%" height={180}>
            <LineChart data={NW_DATA.filter((_,i)=>i%2===0)}>
              <CartesianGrid strokeDasharray="3 3" stroke={t.dim}/>
              <XAxis dataKey="year" stroke={t.dim} tick={{fill:t.muted,fontSize:9,fontFamily:t.body}}/>
              <YAxis stroke={t.dim} tick={{fill:t.muted,fontSize:9,fontFamily:t.body}} tickFormatter={fmtK}/>
              <Tooltip content={<ChartTip t={t}/>}/>
              <Line type="monotone" dataKey="assets" name="Portfolio Assets" stroke={t.accent} strokeWidth={2} dot={false}/>
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </>
  );

  // ─── RENDER ───────────────────────────────────────────────────────────────
  return (
    <div style={APP}>
      {/* ROLE SELECTOR BAR */}
      <div style={{background:t.bg,borderBottom:`1px solid ${t.border}`,padding:"8px 24px",display:"flex",gap:6,alignItems:"center",overflowX:"auto"}}>
        <div style={{fontSize:9,letterSpacing:"0.2em",textTransform:"uppercase",color:t.muted,marginRight:8,fontFamily:t.body,whiteSpace:"nowrap"}}>Active Role:</div>
        {ROLE_ORDER.map(id=>{
          const r = ROLES[id];
          const active = id===roleId;
          return (
            <button key={id} onClick={()=>switchRole(id)} style={{
              padding:"6px 14px", borderRadius:20, border:"none", cursor:"pointer",
              fontFamily:r.body, fontSize:11, fontWeight:active?700:400,
              background:active?r.accent:"transparent",
              color:active?(id==="CLIENT"||id==="COMPLIANCE"?"#fff":ROLES[id].bg):t.muted,
              transition:"all 0.25s", whiteSpace:"nowrap",
              outline:active?`none`:`1px solid ${t.dim}`,
            }}>
              {r.icon} {r.label}
            </button>
          );
        })}
        <div style={{marginLeft:"auto",fontSize:10,color:t.muted,fontFamily:t.body,whiteSpace:"nowrap"}}>{t.tagline}</div>
      </div>

      {/* HEADER */}
      <header style={HEADER}>
        <div style={{width:38,height:38,borderRadius:"50%",background:`linear-gradient(135deg,${t.accent},${t.accent2})`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:18,fontWeight:900,color:t.bg,flexShrink:0}}>S</div>
        <div>
          <div style={{fontSize:15,fontWeight:700,fontFamily:t.display,color:t.text,letterSpacing:"0.03em"}}>Sanlam Financial Planning Engine</div>
          <div style={{fontSize:10,color:t.accent,letterSpacing:"0.15em",textTransform:"uppercase",fontFamily:t.body,marginTop:1}}>{t.tagline}</div>
        </div>
        {/* Tab bar */}
        <div style={{display:"flex",gap:2,marginLeft:24,overflowX:"auto"}}>
          {t.tabs.map((tab,i)=>(
            <button key={tab} style={TAB_BTN(activeTab===i)} onClick={()=>setActiveTab(i)}>{tab}</button>
          ))}
        </div>
        <div style={{marginLeft:"auto",display:"flex",gap:10,alignItems:"center",flexShrink:0}}>
          {roleId==="ADVISER"&&(
            <div style={{fontSize:11,color:t.muted,fontFamily:t.body,textAlign:"right"}}>
              <div style={{color:t.positive}}>● Andile Mokoena</div>
              <div>Plan #2847 · Updated today</div>
            </div>
          )}
          <div style={{width:32,height:32,borderRadius:"50%",background:t.dim,display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,color:t.muted}}>A</div>
        </div>
      </header>

      {/* BODY */}
      <div style={BODY}>
        {/* SIDEBAR */}
        <aside style={SIDEBAR}>
          <div style={{padding:"12px 16px 6px",fontSize:9,letterSpacing:"0.2em",textTransform:"uppercase",color:t.muted,fontFamily:t.body}}>Navigation</div>
          {navItems.map((item,i)=>(
            <div key={i} style={NAV_ITEM(activeTab===i)} onClick={()=>setActiveTab(i)}>
              <span style={{fontSize:12,color:activeTab===i?t.accent:t.muted,fontFamily:t.body}}>{item.slice(0,2)}</span>
              <span style={{fontSize:12,color:activeTab===i?t.text:t.muted,fontFamily:t.body,fontWeight:activeTab===i?600:400}}>{item.slice(2)}</span>
            </div>
          ))}
          <div style={{margin:"16px 12px",borderTop:`1px solid ${t.border}`}}/>
          {roleId==="ADVISER"&&(
            <>
              <div style={{padding:"0 16px 8px",fontSize:9,letterSpacing:"0.2em",textTransform:"uppercase",color:t.muted,fontFamily:t.body}}>Client</div>
              <div style={{padding:"0 16px",marginBottom:16}}>
                <div style={{background:t.card,border:`1px solid ${t.border}`,borderRadius:10,padding:"12px"}}>
                  <div style={{width:32,height:32,borderRadius:"50%",background:`${t.accent}22`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,color:t.accent,fontWeight:700,fontFamily:t.body,marginBottom:8}}>A</div>
                  <div style={{fontSize:12,fontWeight:700,color:t.text,fontFamily:t.body}}>Andile Mokoena</div>
                  <div style={{fontSize:10,color:t.muted,fontFamily:t.body,marginTop:2}}>Age 42 · Plan #2847</div>
                  <div style={{marginTop:8,display:"flex",gap:4}}>
                    <div style={{background:`${t.positive}22`,color:t.positive,borderRadius:4,padding:"2px 6px",fontSize:9,fontFamily:t.body}}>74/100</div>
                    <div style={{background:`${t.accent}22`,color:t.accent,borderRadius:4,padding:"2px 6px",fontSize:9,fontFamily:t.body}}>ADEQUATE</div>
                  </div>
                </div>
              </div>
            </>
          )}
          {roleId==="ACTUARY"&&(
            <div style={{padding:"0 16px"}}>
              <div style={{background:t.card,border:`1px solid ${t.accent}22`,borderRadius:8,padding:"10px 12px"}}>
                <div style={{fontSize:9,color:t.accent,letterSpacing:"0.15em",marginBottom:6,fontFamily:t.mono}}>SIM_STATUS</div>
                <div style={{fontSize:11,color:t.positive,fontFamily:t.mono}}>● READY</div>
                <div style={{fontSize:9,color:t.muted,fontFamily:t.mono,marginTop:4}}>Seed: 0xA3F2<br/>Paths: 10,000<br/>Vars: 47</div>
              </div>
            </div>
          )}
        </aside>

        {/* MAIN */}
        <main style={MAIN}>{renderContent()}</main>
      </div>
    </div>
  );
}
